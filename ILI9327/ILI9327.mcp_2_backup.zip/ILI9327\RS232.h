#ifndef RS232_H_INCLUDED 
#define RS232_H_INCLUDED  
                             
#include <stdio.h>
#include <hidef.h>      /* common defines and macros */
#include "derivative.h"      /* derivative-specific definitions */

#define E_CLOCK    8000000UL
#define RS232_IOREGISTER    SCIDRL 
#define RS232_BAUDLB_REG    SCIBDL
#define RS232_BAUDHB_REG    SCIBDH


#define RS232_CONTROL_REG   SCICR1
#define RS232_CONTROL_REG2  SCICR2

#define RS232_STATUS_REG    SCISR1

#define RS232_STATUS_N81    0x00

/// SCICR2 
/// no declare
#define RS232_TIE   // Transmit Interrupt enable bit
#define RS232_TCIE  // Transmit complete interrupt enable bit
#define RS232_RIE  //  Reciever full interrupt enable bit
#define RS232_ILIE  // Idle line interrupt enable bit 
#define RS232_TE    //  Transmitter enable bit 
#define RS232_RE    //  reciever enable 
#define RS232_RWU   //
#define RS232_SBK   //


//typedef struct RS232_Message			RS232_Message_Node;

//RS232_Message_Node  *Current_Message_Node;

unsigned char RS232_Init(unsigned long baudRate);
char RS232_Write(unsigned char data);
char RS232_Write_String(unsigned char *data);
unsigned char RS232_Read( void );

extern unsigned long RS232_BAUD_RATE; 


#endif    `
