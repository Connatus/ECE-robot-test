#ifndef RCSERVO_H_INCLUDED 
#define RCSERVO_H_INCLUDED

#include <hidef.h>      /* common defines and macros */
#include "derivative.h"      /* derivative-specific definitions */
 #include "Timer.h"


///   ///
/*
1.  Must caputre interrupt input, - measure duty cycel fo input waveform - store result in global 
                                - bitch with flag if nothing is present
                               
                               
2.  read flag and global variable use mutally exclude (CLI) (SEI)        


3.  output compare rc control waveform,  -- 


4.  100Hz ttl CMOSs - connect to input capture, 
                    
*/

#define RCSERVO_PULSE_LENGTH   20 // 20 ms total pulse length 

/// Defines for PULSE in us 
#define RCSERVO_ANGLE_90    2400 
#define RCSERVO_ANGLE_0     1500  
#define RCSERVO_ANGLE_N90    600  

#define RCSERVO_OUTPUT_PIN  PTIT_PTIT2_MASK     //mask 
#define RCSERVO_OUTPUT_PORT PTIT
#define RCSERVO_OUTPUT_DDR  DDRT    //


 /// PT0 // - 

#define RCSERVO_ENABLE_DDR   SETBIT(RCSERVO_OUTPUT_DDR, RCSERVO_OUTPUT_PIN); 
// must be a free running counter /// 0x0000 - 0xFFFF wraps back to 0x0000 - 

#define CLR_TIMER_CHNL_FLAG(chnl) \
          TFLG1 = (1 << (chnl))


#define TIMER_CHNL_INPUT_EDGE(chnl,value) \
          TCTL4 = (value << (chnl*2))


#define TIMER_CHNL_CAPTURE_DISA   0x00
#define TIMER_CHNL_CAPTURE_RISE   0x01
#define TIMER_CHNL_CAPTURE_FALL   0x02
#define TIMER_CHNL_CAPTURE_BOTH   0x03
void capture_input_timer(void);

#endif    
