#include "error.h"



 void ERROR_PRINT_SCREEN(unsigned char errono){

    printf("NIGGERS");
    while(1){
      printf("YOUR DUMBWE");
      
    }
 }
 