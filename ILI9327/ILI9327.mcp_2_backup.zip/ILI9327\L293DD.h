

#ifndef L293DD_H_INCLUDED
#define L293DD_H_INCLUDED
                                            
#include <stdio.h>
#include <hidef.h>      /* common defines and macros */
#include "derivative.h"      /* derivative-specific definitions */

#define     STM_1A     PT4  // - motor1A 
#define     STM_1B     PT5  // - motor1B 

#define     STM_2A     PT6  // - motor2A 
#define     STM_2B     PT7  // - motor2B 

#define     STM_ENABLE   PP7  // motor Enable 

// stepper motor driver 
#endif /* L293DD_H_ */