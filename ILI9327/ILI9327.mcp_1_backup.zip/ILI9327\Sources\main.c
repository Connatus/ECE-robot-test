#include <stdio.h>
#include <hidef.h>      /* common defines and macros */
#include "derivative.h"      /* derivative-specific definitions */
/*

     // GPIO Expander Drivers 
      -- not working either    
*/ 

/*******************************************/
// SD and FAT Libraries 
/*******************************************/
#include "ff.h" // use FatFs from Elm-Chan.org
#include "ffconf.h"
#include "integer.h"
#include "diskio.h" // use FatFs from Elm-Chan.org (diskio used for disk initialization)

/******************************************/ 
#include "Test.h" // UNSORTED PLEASE SORT ME !!!!!
/******************************************/ 


/*******************************************/
// LCD Libraries
/*******************************************/
#include "ILI9327.h" // EL _CD DRIVERSZ
#include "LCD_Draw.h"
#include "LCD_Config.h"
#include "Touch.h"
#include "Terminal.h" // printf 
#include "SD.h" // Sd INIT and File Handlers // needs more work  // broken 
 
/*******************************************/
// Processor Modules 
/*******************************************/
#include "SPI.h"     // garbage 
#include "RS232.h"  // null modem works // needs impr
#include "Analog.h" // 10 - 8 bit 
#include "Timer.h"  // timer and delay

/*******************************************/
// Board Modules 
/*******************************************/
#include "MAX5513.h"   // DAC 
#include "Accelerometer.h"
#include "RC_Servo.h" // timer n stuff 
#include "MCP23009.h" // Not complete //   -- doesnt work properly 

/*******************************************/
// Macros N stuffs
/*******************************************/    
#include "macros.h"


#include "error.h" /// not in file for fuck sake need to search the god damn 

volatile int data_in , data_2; 
 
 unsigned char RS232_Send_Node(void);  
 
void Process_RS232(unsigned char *RS232_INPUT, unsigned char Length); 



/* 
  RS232 - data array 
  Pointer - 
  Termination string - 0xDEAD - 0xBEEF
*/
unsigned char RS232_Termination_String[4] = {
 //  0xDE, 0xAD, 0xBE, 0xEF
   'a','b', 'c','d'
};

unsigned char RS232_Transmission_String[4] = {
  //  0xFE, 0xED, 0xDE, 0xAD 
   'q','w','e','r'
};



volatile unsigned char Error_Flag_Number; 

// INTERUPT VARIABLE 
unsigned char RS232_Data_Input[10];
unsigned char RS232_Counter;  /// 0 
unsigned char RS232_Recieve_Flag;
 
char   RS232_Com_PORT;
char   Board_Function; 
char	 MessageSequenceNumber;  //  Place in packet   in a message package of 430 bytes( 2 - 140- 279)
char	 lDataLength;     // size of message sent after the heade

// both need to be volaitle // they are used outside of interrupt routine 
volatile unsigned char 	MessageStorageArray[120]; // leave room for terminating chars
volatile unsigned char   Message_Storage_Counter; 

volatile char   RS232_Processed_Data_Flag; 
unsigned char   RS232_Transmission_Flag;


volatile unsigned char FUCKER; 
unsigned char RS232_Counter_; 

///END 

void ASMSTUFF(void);
void RS232_INIT(void);


/////// SD And FAT
void SD_INIT_FAT(void);


FATFS filesystem;
FRESULT errCode;
unsigned char buff[64];
UINT read;
FIL file; 

void main(void) {
   unsigned int i =0;
   unsigned char Error =0;
   struct LCD_Geometry *pointCurrent= &Current;
   unsigned int Local_Process =0; 
   unsigned int Local_counter =0;
   unsigned char Local_Error_Flag_Number =0;  
   Error_Flag_Number =0; 
   
   
   //Always init display frist 
   ILI9327_INIT();
      
   RS232_INIT();



//  SD_INIT(); 
SD_INIT_FAT();

  while(1){
    asm("NOP"); 
    continue; 
  }
  
  
  
  /*  RS232 adn ERROR SCREEN STUFF */ 
   // enable interrupt in main only once 
   // asm("CLI"); 
  
  //Accelerometer_Test(); 


   while(1){
    //  RS232_ECD(5); 
         //Error=  RS232_Read(); 
   // printf("0x%x", Error); 
   
   
 

    asm("SEI"); 
     Local_Process = RS232_Processed_Data_Flag; 
     Local_counter =Message_Storage_Counter; 
     Local_Error_Flag_Number = Error_Flag_Number; 
    asm("CLI");
    
    
    if(Local_Error_Flag_Number != 0x00){
      asm("SEI"); 
       ERROR_PRINT_SCREEN(Local_Error_Flag_Number);
    }
    
   if(Local_Process){
    // print out aray // 
    asm("SEI"); 
     printf("\n\nDATA CAME\n ----------- \nLength %d \n",Message_Storage_Counter); 
      printf("MSC:%d", Message_Storage_Counter); 
  /*   for(i=0; i< 100; i++){ 
       printf("0x%x, ",	MessageStorageArray[i]);    
     }
        Local_Process =0; 
    */
      Process_RS232(MessageStorageArray,100);  
    
	 	Message_Storage_Counter = 0; 
      RS232_Processed_Data_Flag = 0; 
    asm("CLI");
   
   }
   
    
            
   for(Error=0; Error < 240; Error++)
      asm("NOP");
   }
 
 
  // printf(" %d %d  ", MCP23009_OPCODE_WRITE,MCP23009_OPCODE_READ); 


  
// Analog_Init(ANALOG_10BIT);
 //Touch_Test();

//MAX5513_Test();
 //Accelerometer_Test(); 


   
   
}


void SD_INIT_FAT(void){

    FRESULT rc; /* Result code */
    DIR dir; /* Directory object */
    FILINFO fno; /* File information object */
    UINT bw, br, i;

     ILI9327_INIT();
     SD_INIT();  
     
     errCode = f_mount(0, &filesystem);
      if (errCode != FR_OK)
      {
      printf("Error: f_mount failed, error code: %d\r", errCode);
      printf("Please refer to error list");
      while (1); // freeze
      }
      printf("\n Mounted File System: Type SD");
      // Draw BMP
      printf("\nCreate a new file (hello.txt).\n");
      rc = f_open(&file, "HELLO.TXT", FA_WRITE | FA_CREATE_ALWAYS);
      printf("\nWrite a text data. (Hello world!)\n");
      rc = f_write(&file, "Hello world!\r\n", 14, &bw);
      printf("%u bytes written.\n", bw);
      printf("\nClose the file.\n");
      rc = f_close(&file); 
     
     
}

void RS232_INIT(void){

// Init Vars for RS232
   RS232_Processed_Data_Flag= 0;
   RS232_Recieve_Flag = 0; 
   RS232_Counter = 0; // set counter to 0;   
   ERROR_PRINT_SCREEN( RS232_Init(9600)); 	

}

         //interrupt 8 void TC0handler(void){
     // RDRF IS ONLY INTERUPTED 
     /*
     13.5.2.2.3 RDRF Description
The RDRF interrupt is set when the data in the receive shift register transfers to the SCI data register. A
RDRF interrupt indicates that the received data has been transferred to the SCI data register and that the
byte can now be read by the MCU. The RDRF interrupt is cleared by reading the SCI status register one
(SCISR1) and then reading SCI data register low (SCIDRL)
     */



void Process_RS232(unsigned char *RS232_INPUT, unsigned char Length){
    unsigned char counter = 0; 
    
    printf(" \n data length %d ", Length); 
   
      for(counter=0; counter < Length; counter++){
          
         switch(counter){
          case 0:
             // COMPORT
            RS232_Com_PORT =  MessageStorageArray[counter];
            printf("\n ComPort: %d", RS232_Com_PORT); 
            break;
          case 1: 
             // Board Function
             Board_Function =    MessageStorageArray[counter];
             printf("\nBoard_Function: %d ", Board_Function);
             break;
          case 2:
             // Data Sequence 
             MessageSequenceNumber=   MessageStorageArray[counter];
             printf("\nMessageSequenceNumber: %d", MessageSequenceNumber);
            break;
          case 3:
            // Packet length
            lDataLength =   MessageStorageArray[counter];
            printf("\nLdatalenghtL: %d", lDataLength); 
            break;  
         }  
         
         if(counter == 4)
            printf("\n Message Stored: %c, ",  MessageStorageArray[counter]);
         else if (counter >4)
            printf("%c ", MessageStorageArray[counter]);
      }
 
      

  return;
}


     /*
     13.5.2.2.3 RDRF Description
The RDRF interrupt is set when the data in the receive shift register transfers to the SCI data register. A
RDRF interrupt indicates that the received data has been transferred to the SCI data register and that the
byte can now be read by the MCU. The RDRF interrupt is cleared by reading the SCI status register one
(SCISR1) and then reading SCI data register low (SCIDRL)
     */
/// non ideal code should only analyze the termination, and transmission // 
interrupt 20 void SCIhandler(void){
     
    
     RS232_Counter_ = (RS232_Counter%4);
     // Check Flag for RDRF // INPUT READ 
     //   cleared by reading the SCI status register one
     //(SCISR1) and then reading SCI data register low (SCIDRL)
     // 
   if ((SCISR1 & SCISR1_RDRF_MASK)){
     RS232_Data_Input[RS232_Counter_] = SCIDRL;             
     data_in = SCISR1;    // clear flag 
     RS232_Write(RS232_Data_Input[RS232_Counter_]); 
     // printf("%c", RS232_Data_Input[RS232_Counter_]); //       not useful delay large!
   }
   
    // read for starting string //
    ///Costly if statment only compare if Recieve flag =0 
   if(!RS232_Recieve_Flag){
    
     if((RS232_Transmission_Flag ==3) && (RS232_Data_Input[(RS232_Counter_)] == RS232_Transmission_String[3]))  {
            RS232_Transmission_Flag =4;
          //  printf("FLAG 4");
     }
      else if(RS232_Transmission_Flag ==3) 
            RS232_Transmission_Flag =0;
     
     
       if((RS232_Transmission_Flag ==2) && (RS232_Data_Input[(RS232_Counter_)] == RS232_Transmission_String[2])) {
            RS232_Transmission_Flag =3;
        //   printf("FLAG 3");
     }
      else if(RS232_Transmission_Flag ==2) 
            RS232_Transmission_Flag =0 ;
     
      if((RS232_Transmission_Flag ==1 ) && (RS232_Data_Input[(RS232_Counter_)] == RS232_Transmission_String[1])) {
            RS232_Transmission_Flag =2;
        // printf("FLAG 2");
     }
      else if(RS232_Transmission_Flag ==1) 
            RS232_Transmission_Flag =0; 

      if(RS232_Data_Input[(RS232_Counter_)] == RS232_Transmission_String[0])
            RS232_Transmission_Flag =1;
     
            if (RS232_Transmission_Flag ==4){
                 //printf("FLAG Get SET"); 
                 Message_Storage_Counter =0; // reset counter
                 RS232_Transmission_Flag =0;   
                 RS232_Recieve_Flag = 1; 
        
              }   
   }
        
        
          
    // read ending string // 
   // read for starting string //
    ///Costly if statment only compare if Recieve flag =0 
   if(RS232_Recieve_Flag == 1){
      
   // Record incoming rs232 message   
        MessageStorageArray[Message_Storage_Counter++] = RS232_Data_Input[RS232_Counter_]; 
   
         
      // printf("%c ",MessageStorageArray[Message_Storage_Counter-1]); 

   /// messy // if termination flag =0 it compares all values of termination string with current data input// 
   /// not  nice but fast // 
      if((MessageStorageArray[(Message_Storage_Counter-1)] == RS232_Termination_String[3] )&& 
      (MessageStorageArray[(Message_Storage_Counter-2)]  == RS232_Termination_String[2])&&  
      (MessageStorageArray[(Message_Storage_Counter-3)]  == RS232_Termination_String[1]) && 
      (MessageStorageArray[(Message_Storage_Counter-4)]  == RS232_Termination_String[0]) ){
          
           RS232_Recieve_Flag = 0; 
           RS232_Processed_Data_Flag= 1; // set processed flag high for main 
           RS232_Counter =0;
        
           return; 
     }
 

     
   }
  
  ///
  if (Message_Storage_Counter > 115){
       Error_Flag_Number = 12;
       RS232_Recieve_Flag = 0; 
       RS232_Processed_Data_Flag= 0; // set processed flag high for main 
       RS232_Counter =0;   
      return; 
  }
  // put in case for if Message_Storage counter  > 120 
      
  RS232_Counter++;    
  return; 
}  
 /*
unsigned char RS232_Send_Node(void){
  struct RS232_Message *Message_Node = &RS232_Message_Node;
   	unsigned int counter =0; 
   	unsigned char hellos[6] = "hello";
  	for(counter= 0; counter < 119; counter++){
  	    Message_Node->MessageStorageArray[counter] = (counter);
  	    printf(" %d", Message_Node->MessageStorageArray[counter] ); 
  	
  	}
  	Message_Node->MessageStorageArray[counter++] = '\0'; 
  	Message_Node->MessageSequenceNumber = 0x01; 
  	Message_Node->lDataLength = counter; 
  	Message_Node->Message_CRC = 0xBEEF; 
  	
   // RS232_Write_String(Message_Node->MessageStorageArray);   //
    printf("\n Data: %s", Message_Node->MessageStorageArray);   // %s doesnt work with storage arrays 
    printf("\n Data: %s", hellos);
   //
    printf("\n MessageSequenceNumber: %d", (Message_Node->MessageSequenceNumber));    // 394 
    printf("\n DataLength: %d", (Message_Node->lDataLength));    // 394 
    printf("\n Message_CRC: %d", (Message_Node->Message_CRC));    // 394    
  
}
*/


