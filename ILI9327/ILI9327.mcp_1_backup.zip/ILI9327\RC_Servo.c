#include "RC_Servo.h" 


              /// let PT0 or PT1 be the input 

void capture_input_timer(void){

      
      TSCR1 = (TSCR1_TFFCA_MASK | TSCR1_TEN_MASK );      /* enable TCNT and fast timer flag clear */
      TSCR2 = TSCR2_TIMER_PR_8; 
      /// TIOS  // controls IO  capture
      TIOS &= ~( TIOS_IOS0 | TIOS_IOS1);  // 0 - input capture
      TIOS |=  (RCSERVO_OUTPUT_PIN); // 1 output 
    //  DDRT &=  ~( TIOS_IOS0 | TIOS_IOS1);  // 0 - input capture 
      
      // set for only 0 
      /// TIE  interrupt enable
      TIE |= (TIE_C0I);           /// enable interrupt on T0 
      
      //// TFLG1 Timer event flags 
    //  TFLG1 = (TFLG1_C0F) // allow for interrupt when condition has occured 
     TIMER_CHNL_INPUT_EDGE(0x00, TIMER_CHNL_CAPTURE_FALL);  
}


/// TFLG2 used for overflow 