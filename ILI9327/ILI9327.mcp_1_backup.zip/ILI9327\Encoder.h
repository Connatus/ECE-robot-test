

#ifndef ENCODER_H_INCLUDED
#define ENCODER_H_INCLUDED
                                            
#include <stdio.h>
#include <hidef.h>      /* common defines and macros */
#include "derivative.h"      /* derivative-specific definitions */

#define     ENC_A    PT0  // - Enable Encoder A // pull high
#define     ENC_B    PT1  // - Enable Encoder B // pull high 

// stepper motor driver 
#endif /* ENCODER_H_INCLUDED */