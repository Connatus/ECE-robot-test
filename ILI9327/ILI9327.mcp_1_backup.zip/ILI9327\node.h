/*
* Node.h
*/
#ifndef NODE_H_INCLUDED_
#define NODE_H_INCLUDED_


#include <stdio.h>      /* printf */
#include <stdlib.h>     /* rand, srand , malloc*/

#define iLen			// # of characters to copy from fortune cookie text file. 
#define FileFlag 0x25
#define FileStorageSize	60000 // seen some messages 2000- 5000 chars in length lets use more space than necessary
#define FileMaxNumberofDelimiters	1000

 /*change to non static values
#define SENDERID 			0x534e  //SN 
#define RECIEVERID 		    0x5243   //RC 
*/ 

// Delete node




#endif /* _H_ */