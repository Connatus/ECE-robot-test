#ifndef ERROR_H_INCLUDED
#define ERROR_H_INCLUDED
                                            
#include <stdio.h>
#include <hidef.h>      /* common defines and macros */
#include "derivative.h"      /* derivative-specific definitions */


 void ERROR_PRINT_SCREEN(unsigned char errono);
 

#endif /* */


