#ifndef SWITCHES_H_INCLUDED
#define SWITCHES_H_INCLUDED
                                            
#include <stdio.h>
#include <hidef.h>      /* common defines and macros */
#include "derivative.h"      /* derivative-specific definitions */
   // Camer header // 
  
#define     SWITCH_RIGHT_     PS3  
#define     SWITCH_LEFT_      PS2   



#endif /* SWITCHES_ */