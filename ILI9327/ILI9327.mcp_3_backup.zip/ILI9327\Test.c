#include "Test.h"



 
 
/*
Functions to init device, move motor with parameters for speed, direction, full/half step, continuous or fixed number of steps.
Stepping happens in ISR.
Function to get motor's current position and state.
*/ 
unsigned char Stepper_Motor_ECD(void){ 

return 0; 
} 

 /*
Function to init device, set position of servo.  
Sweep function with final position and time as parameters  (uses ISR)
*/  
unsigned char RC_Servo_ECD(void){

 return 0;
 } 
 
/*
Open-loop Motor() function as on Handy Board Interactive C
- can move both motors in both directions
*/  
unsigned char DC_Motor_ECD(void){ 

return 0; 
} 

/*
  Adding to the basic techniques,
- can correctly handle a wide range of motor speeds in both directions
- can measure both motor speeds simultaneously
- Motor() function capable of handling changes in direction automatically
(stop, wait for encoder, restart in other direction)
- handles timer wrap correctly

*/ 
unsigned char DC_Motor_Encoder_ECD(void){

 return 0; 
}


unsigned char RS232_ECD(unsigned char COM_PORT){
  
   unsigned char RS232_Input =0; 
   terminalemulator(); //reset current terminal emulator 
    printf("\n Begin Communication with COM%d",COM_PORT);
    printf("\n BaudRate: %lu ", RS232_BAUD_RATE);   
    printf("\n Control Reg 1: %d     Control Reg 2: %d",RS232_CONTROL_REG, RS232_CONTROL_REG2); 
    printf("\n Begin Input: ");
    asm("SEI"); // DISABLE INTERRUPTS FOR RS232  
   for(;;){
     RS232_Input = RS232_Read();
     printf("%c", RS232_Input);
     
     if(RS232_Input == 0x1B || RS232_Input == 0x7F) {
      printf("Ending Program"); 
      asm("CLI");    // ENABLE AND RETURN 
      return 0; 
     }
 
   }

  return 0; 
} 

/*
Interrupt Rx, Polled Tx, functions to init device, send/receive strings (like puts/gets)
*/
unsigned char SerialTerminal_ECD(void){

 return 0;
} 
  
 
/*
Function to get the ADC value of a particular channel (like analog() function in IC).  
Function to read all 3 axes of the accelerometer and return in an array (passed in as a parameter)
 as engineering units with fixed point representation. 
*/ 
unsigned char Accelerometer_ECD(void){
    Accelerometer_Test(); 
 return 0; 
} 


/*
Function to init SPI port and DAC.  Write a specified value to the specified DAC channel.
Demonstrate by generating a waveform and sending to the DAC.  Display on scope
*/
unsigned char DAC_ECD(void){
    MAX5513_Test(); 
 return 0; 
} 



/// LCD TEST, ACCELEROMETER TEST, SPI TEST, RS232_TEst , TOUCH_SCREEN TEST 
/// NEEDS MOTOR TESTS, SD Test, encoders etc. MORE NEEDED



void ILI9327_INIT(void){
     ILI9327_INITALIZE(); 
    
      
  terminalemulator();            
     return; 
}

void Touch_Test(void){
       unsigned int *touch_xy;
       unsigned char *test;
        
  for(;;){

  /// its pretty okay //no float // so not exact but pretty damn close 
   touch_xy = Touch_Screen_XY_Res();
    printf("\n x: %d  y: %d ", *(touch_xy +0), *(touch_xy + 1)); 
  
    Timer_Delay_10ms(30);
  }
}

void MAX5513_Test(void){
  unsigned char countx =0; 
	unsigned char MAX5513_INPUT = 7; 
	Analog_Init(1);
  ANALOG_ENABLE_PIN(MAX5513_INPUT);
  ANALOG_ENABLE_PIN(MAX5513_INPUT-1);
  printf("\nAnalog On PIN #%d", MAX5513_INPUT);
  printf("\nAnalog On PIN #%d", MAX5513_INPUT-1);  
  
  SPI_INIT(400000);
  SPI_Toggle_MasterSS(0);  // disable slave select from master                                          
  MAX5513_ON_3_4V(); // max voltage  
	MAX5513_INIT_DDR();
	  
	// Make Square // Make Triangle  
	   for(;;){
	      
	       MAX5513_Set_Chan(0xFF,2);
	       MAX5513_Set_Chan(countx++,1); //   make forever triangle
         Timer_Delay_10us(1);
         MAX5513_Set_Chan(0x00,2);
	       Timer_Delay_10us(1); 
	   }

  return;         
}




   // use null modem // 9600 baud     
void Test_RS232(void){
  unsigned char x=0, y=0;
   RS232_Init(9600);
   while(1){
      x++; 
       RS232_Write(x);
       printf("\n RS232 Write= 0x%x", x); 
     y= RS232_Read();
       printf(" Read= 0x%x",y); 
   }

  return; 
}
 
void testanal(void){

    DDRAD = 0xFF; 
    //ATDDIEN = 0x00;
  
  while(1){
      
      ILI9327_RESET_HIGH();
       ILI9327_CS_HIGH();
        ILI9327_RS_HIGH();
        ILI9327_WR_HIGH();  
         ILI9327_RD_HIGH();
         
    	Timer_Delay_1ms(5);
      
        ILI9327_CS_LOW() ; 
       ILI9327_RS_LOW();  
       ILI9327_WR_LOW();
       ILI9327_RD_LOW();  
      ILI9327_RESET_LOW() ;
      
    	Timer_Delay_1ms(5);
  
  }    
   

}
         

          

// CRAPPY TEST ROUTINE !!! YAY IT SUCKS
void testLibrary(void){
   int x, y;
   int colorFill;
	char *helloworld = "he"; 
		//ReadBMP_ARRAY(40,40,BMP_IMAGE2);
//	for (int y= 3; y < 4; y++){
//		pointProperties->Rotation= y; 
		    ILI9327_Fill_Rectangle(0,0,400,240,0x000000); 
		
		LCD_Write_Line("Demo for Rotation: ",50,180,2,0xFFFFFF);
	//	pointCurrent->xPosition = 130;
	//	pointCurrent->yPosition = 40; //// if the string goes off the screen my code doesn't care doesn't display at all only x is cared about
	//	pointCurrent->size = 9;
		LCD_Write_Char(0x30);
		Timer_Delay_1ms(6000);
			
		    ILI9327_Fill_Rectangle(0,0,400,240,0x000000); ;
		for (colorFill=0; colorFill <12; colorFill++){
			LCD_Draw_FillCircle(colorFill*20, 10*colorFill*2, 20+(colorFill*10), 1, colorArray[colorFill]);
		}
		
	    ILI9327_Fill_Rectangle(0,0,400,240,0x000000); 
		
		for ( colorFill=0; colorFill <16; colorFill++){
			LCD_Fill_Rectangle(0,0,500,500, colorArray[colorFill]);
		}
		    ILI9327_Fill_Rectangle(0,0,400,240,0x000000); 

		for (x=0; x < 12; x++)
		{
			for (y=0; y < 16; y++ )
			{
				LCD_Draw_Line(0,0,x*20,y*30,2,colorArray[x]);
			}
		}
	
		    ILI9327_Fill_Rectangle(0,0,400,240,0x000000);  
		Timer_Delay_1ms(6000);
		
		
		LCD_Write_Line("Standard Terminal Font:",10, 220,2,0xFFFFFF);  
		LCD_Write_Line("!#$%&'()*+,-.0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[]^_`abcdefghijklmnopqrstuvwxyz", 20,180,1, 0xFFFFFF);
		LCD_Write_Line("Arial Font:",10, 120,2,0xFFFFFF);  
	//	LCD_Write_Style_Line(FontDemo,20,80,1, 0xFFFFFF);	
		Timer_Delay_1ms(6000);
	
	
	
		
		    ILI9327_Fill_Rectangle(0,0,400,240,0x000000); 
	//	ReadBMP_ARRAY(0,150, 2,BMP_IMAGE);
//		ReadBMP_ARRAY(10,0, 1,BMP_IMAGE);

printf("\n Lets display some variables! \n Hex: 0x%x 0x%x 0x%x 0x%x \n Decimal: %d \n String: %s",
1,2,3,4 , 42, helloworld);
printf(" You are currently viewing the display in rotation: %d ", y);
printf("\n Thanks for choosing my software be sure to check out my other libraries and demos on www.electricsheep.info");

		Timer_Delay_1ms(6000);
		

	
}



 // Short Mosi and MISo // should yield the same result 
void TEST_SPI(void){
   unsigned char Error =0; 
   SPI_INIT(400000);
   SPI_Toggle_MasterSS(0); 
   
  while(1){
     SPI_Send_Char(0xA5); 
    Error =  SPI_Recieve_Char(0x00);
    printf(" %x ", Error); 
    Error = 0x00; 
  }
   


}
