#include <stdio.h>
#include <hidef.h>      /* common defines and macros */
#include "derivative.h"      /* derivative-specific definitions */
/*

FONT IS BROKEN PLEASE NOTE FONT ISNT THE FULL ARRAY ?/
*/ 

/*******************************************/
// SD and FAT Libraries 
/*******************************************/     /*
#include "ff.h" // use FatFs from Elm-Chan.org
#include "ffconf.h"
#include "integer.h"
#include "diskio.h" // use FatFs from Elm-Chan.org (diskio used for disk initialization)
#include "file.h"
                */
/******************************************/ 
#include "Test.h" // UNSORTED PLEASE SORT ME !!!!!
/******************************************/ 


/*******************************************/
// LCD Libraries
/*******************************************/
#include "ILI9327.h" // EL _CD DRIVERSZ
#include "LCD_Draw.h"    // only has rect, pix, char and string
#include "LCD_Config.h"
#include "Touch.h"
#include "Terminal.h" // printf 
#include "SD.h" 
#include "BMP.h" // 

/*******************************************/
// Processor Modules 
/*******************************************/
#include "SPI.h"     // garbage 
#include "RS232.h"  // null modem works // needs impr
#include "Analog.h" // 10 - 8 bit 
#include "Timer.h"  // timer and delay

/*******************************************/
// Board Modules 
/*******************************************/
#include "MAX5513.h"   // DAC 
#include "Accelerometer.h"
#include "RC_Servo.h" // timer n stuff 
#include "MCP23009.h" // Not complete //   -- doesnt work properly 

/*******************************************/
// Macros N stuffs
/*******************************************/    
#include "macros.h"


#include "error.h" /// ERRORNO

 


///END 

void ASMSTUFF(void);
void RS232_INIT(void);
void RS232_TEST(void); // used to test the interrupt rs232 

/////// SD And FAT
void SD_INIT_FAT(void);



void main(void) {
   unsigned int i =0;
   unsigned char Error =0;
   struct LCD_Geometry *pointCurrent= &Current;
   unsigned int Local_Process =0; 
   unsigned int Local_counter =0;
   unsigned char Local_Error_Flag_Number =0;  
   Error_Flag_Number =0; 
   
  // init lcd
  ILI9327_INIT();
    
  // init sd // write hello world // 
  SD_INIT_FAT();
  
  //ERROR_PRINT_SCREEN_2("ERROR", 2); 
  
  
   /// print out accelerometer to file// 
// Accelerometer_Test_2(); 
  
  
  printf("waitforever");
    while(1){
     asm("NOP");
    continue; 
  }
  
   
   //Always init display frist 
      
   RS232_INIT();


  
  /*  RS232 adn ERROR SCREEN STUFF */ 
   // enable interrupt in main only once 
   // asm("CLI");  
  // printf(" %d %d  ", MCP23009_OPCODE_WRITE,MCP23009_OPCODE_READ); 


  
// Analog_Init(ANALOG_10BIT);
 //Touch_Test();

//MAX5513_Test();
 //Accelerometer_Test(); 


}



void SD_INIT_FAT(void){
   unsigned int fuck =0;
   unsigned char fontshit[5];  
   unsigned char fucker =0; 
   SD_INIT();      
   errCode = f_mount(0, &filesystem);
   Fat_FS_Error(errCode,"f_mount");
   printf("\n Mounted File System: Type SD");
   Write_Hello_World(); 
}



void RS232_INIT(void){

// Init Vars for RS232
   RS232_Processed_Data_Flag= 0;
   RS232_Recieve_Flag = 0; 
   RS232_Counter = 0; // set counter to 0;   
   ERROR_PRINT_SCREEN( RS232_Init(9600)); 	

}


void RS232_TEST(void){
     unsigned int i =0;
   unsigned char Error =0;
   struct LCD_Geometry *pointCurrent= &Current;
   unsigned int Local_Process =0; 
   unsigned int Local_counter =0;
   unsigned char Local_Error_Flag_Number =0;  
   Error_Flag_Number =0; 
   
    RS232_INIT();
     asm("CLI"); 
    
   while(1){
    //  RS232_ECD(5); 
         //Error=  RS232_Read(); 
   // printf("0x%x", Error); 
   
   
 

    asm("SEI"); 
     Local_Process = RS232_Processed_Data_Flag; 
     Local_counter =Message_Storage_Counter; 
     Local_Error_Flag_Number = Error_Flag_Number; 
    asm("CLI");
    
    
    if(Local_Error_Flag_Number != 0x00){
      asm("SEI"); 
       ERROR_PRINT_SCREEN(Local_Error_Flag_Number);
    }
    
   if(Local_Process){
    // print out aray // 
    asm("SEI"); 
     printf("\n\nDATA CAME\n ----------- \nLength %d \n",Message_Storage_Counter); 
      printf("MSC:%d", Message_Storage_Counter); 
  /*   for(i=0; i< 100; i++){ 
       printf("0x%x, ",	MessageStorageArray[i]);    
     }
        Local_Process =0; 
    */
      Process_RS232(MessageStorageArray,100);  
    
	  	Message_Storage_Counter = 0; 
      RS232_Processed_Data_Flag = 0; 
     asm("CLI");
   
   }
   
   Accelerometer_Test(); 
            
   for(Error=0; Error < 240; Error++)
      asm("NOP");
   }

}

 /*
unsigned char RS232_Send_Node(void){
  struct RS232_Message *Message_Node = &RS232_Message_Node;
   	unsigned int counter =0; 
   	unsigned char hellos[6] = "hello";
  	for(counter= 0; counter < 119; counter++){
  	    Message_Node->MessageStorageArray[counter] = (counter);
  	    printf(" %d", Message_Node->MessageStorageArray[counter] ); 
  	
  	}
  	Message_Node->MessageStorageArray[counter++] = '\0'; 
  	Message_Node->MessageSequenceNumber = 0x01; 
  	Message_Node->lDataLength = counter; 
  	Message_Node->Message_CRC = 0xBEEF; 
  	
   // RS232_Write_String(Message_Node->MessageStorageArray);   //
    printf("\n Data: %s", Message_Node->MessageStorageArray);   // %s doesnt work with storage arrays 
    printf("\n Data: %s", hellos);
   //
    printf("\n MessageSequenceNumber: %d", (Message_Node->MessageSequenceNumber));    // 394 
    printf("\n DataLength: %d", (Message_Node->lDataLength));    // 394 
    printf("\n Message_CRC: %d", (Message_Node->Message_CRC));    // 394    
  
}
*/


