#ifndef SYSCLOCK_H_INCLUDED
#define SYSCLOCK_H_INCLUDED
                                            
#define E_CLOCK    8000000UL



#endif /**/