#ifndef L2665_H_INCLUDED
#define L2665_H_INCLUDED
                                            
#include <stdio.h>
#include <hidef.h>      /* common defines and macros */
#include "derivative.h"      /* derivative-specific definitions */
   // DC motor Driver 
  
#define     DCM_1A     PB0  // - motor1A 
#define     DCM_1B     PB1  // - motor1B 

#define     DCM_2A     PB2  // - motor2A 
#define     DCM_2B     PB3  // - motor2B 

#define     DCM_STIN_ENABLE_A   PP4  // motor Enable A
#define     DCM_STIN_ENABLE_B   PP5  // motor Enable B


#endif /* L2665_H_ */