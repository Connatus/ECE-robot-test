
#include "Accelerometer.h"
#include <math.h>
/// outputs ACC  to display 
//// needs to give direction // interrupt driven??? 
/// fuck no thats really complicated//
/// The amplifier gives     
//http://cache.freescale.com/files/sensors/doc/app_note/AN3107.pdf    

// Min = 350   Max = 850 

/*
FLOATS ARE NOT POSSIBLE TOO MUCH CODE SPACE


REST:              Gain from Amplifier is 1.52 // should result in a max voltage of 5v out from the ACC
  x:      500    == 2.44v   
  y:      611    == 2.98v
  z:      830    == 4.05v  can float around +-5 

/// (0.145*3.3v) per G 


*/

#define Accelerometer_Tollerance 10 // not in percent but in analog value // approx 1% 
#define Accel_X_Zero   580
#define Accel_Y_Zero   610
#define Accel_Z_Zero   830



/*
 X -- Left  = Negative
   X -- Right = Positive 
   
   Y -- TWIST  Clockwise = Negative
   Y -- Twist  Counter CLock = Positive 
   
   Z -- UP  == Positive 
   Z -- DOWN == NEGATIVE
*/ 

// write to file 
void Accelerometer_INIT(void){
  unsigned int anal_x, anal_y, anal_z; 
  Analog_Init(0);
  ANALOG_ENABLE_PIN(7);
  
  ACCELEROMETER_INIT_DDR(); 
  ACCELEROMETER_ENABLE(); 
  
  
   // test values //  
   ACCELEROMETER_X();  
     anal_x= Analog_Read(0x5);
      Timer_Delay_1ms(1);
   ACCELEROMETER_Y();  
     anal_y= Analog_Read(0x5);
      Timer_Delay_1ms(1);
   ACCELEROMETER_Z();  
     anal_z= Analog_Read(0x5);  
   
   if(!anal_x || !anal_y || !anal_z)
      ERROR_PRINT_SCREEN_2("Analog Or Accel Init Error", 5);  
   return; 
  
}

void Accelerometer_Test_2(void){
  char *filename = "Accelerometer.txt"; 
  unsigned int anal_x, anal_y, anal_z; 

 // Int Accel// 
  Accelerometer_INIT(); 
  
  printf("\nOpening file (%s), going to store accel values here \n");
  errCode = f_open(&file, filename, FA_WRITE | FA_CREATE_ALWAYS);
  Fat_FS_Error(errCode,"f_open");
       
  while(1){
  
      
   ACCELEROMETER_X();  
     anal_x= Analog_Read(0x5);
      Timer_Delay_1ms(1);
   ACCELEROMETER_Y();  
     anal_y= Analog_Read(0x5);
      Timer_Delay_1ms(1);
   ACCELEROMETER_Z();  
     anal_z= Analog_Read(0x5);  
   
    Timer_Delay_1ms(1);
    
     printf("\n x:%d y:%d z:%d", anal_x, anal_y, anal_z);     
     f_printf(filename, "x: %d y: %d z: %d \n", anal_x, anal_y,anal_z ); 
     Fat_FS_Error(errCode,"f_open");
  }
  
  return;
}

void Accelerometer_Test(void){
      unsigned int anal_x, anal_y, anal_z; 

//  DDRP = 0xFF; 
  Analog_Init(0);
  ANALOG_ENABLE_PIN(7);
  
  ACCELEROMETER_INIT_DDR(); 
  ACCELEROMETER_ENABLE(); 

 //   anal_x  =asin(2);
    ANALOG_ENABLE_PIN(0x5);
  
  for(;;) {
  
   ACCELEROMETER_X();  
     anal_x= Analog_Read(0x5);
      Timer_Delay_1ms(1);
   ACCELEROMETER_Y();  
     anal_y= Analog_Read(0x5);
      Timer_Delay_1ms(1);
   ACCELEROMETER_Z();  
     anal_z= Analog_Read(0x5);  
   
    Timer_Delay_1ms(1);
     printf("\n x:%d y:%d z:%d", anal_x, anal_y, anal_z);         
   
  }

}
