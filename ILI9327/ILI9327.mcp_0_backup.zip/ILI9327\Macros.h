#ifndef MACROS_H_INCLUDED 
#define MACROS_H_INCLUDED


#include <hidef.h>      /* common defines and macros */
#include "derivative.h"      /* derivative-specific definitions */
            
#define SETBIT_SHIFT(ADDRESS,BIT)           (ADDRESS |= (1<<BIT))
#define CLEARBIT_SHIFT(ADDRESS,BIT)         (ADDRESS &= ~(1<<BIT))
#define FLIPBIT_SHIFT(ADDRESS,BIT)          (ADDRESS ^= (1<<BIT))
#define CHECKBIT_SHIFT(ADDRESS,BIT)         (ADDRESS & (1<<BIT))


#define SETBIT(ADDRESS,BIT)           (ADDRESS |= (BIT))
#define CLEARBIT(ADDRESS,BIT)         (ADDRESS &= ~(BIT))
#define FLIPBIT(ADDRESS,BIT)          (ADDRESS ^= (BIT))
#define CHECKBIT(ADDRESS,BIT)         (ADDRESS & (BIT))
//#define Delay_1us()  asm("nop"); 
//#define Delay_125ns(x)  for(;x >0;x--) asm("nop"); 

//#define Delay_125ns(x)                 \
//  for (;;) {                \
 //    asm("nop");                      \
//  }



    
#endif    `