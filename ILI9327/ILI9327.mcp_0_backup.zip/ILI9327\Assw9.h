#ifndef ASSW9_H_INCLUDED 
#define ASSW9_H_INCLUDED

#include <hidef.h>      /* common defines and macros */
#include "derivative.h"      /* derivative-specific definitions */


#endif    `
