/*


1.  Caputre one timer channel to measure duty cycle of an input waveform ,
2.  generate an RC serveo control waveform - separate channel - derived from input signal 

1 speaks to 2.

 
 -90     600us 
   0     1500us
  90     2400us
  
 Input comes from signal generator (100Hz square wave - positive -active duty cycle) 
        -90    25%
        0      50%
        90     75%
        
    /// due march 30
    
 

*/



#include "Assw9.h"