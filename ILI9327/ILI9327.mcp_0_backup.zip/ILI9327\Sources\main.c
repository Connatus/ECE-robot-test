#include <stdio.h>
#include <hidef.h>      /* common defines and macros */
#include "derivative.h"      /* derivative-specific definitions */

// LCD Libraries
#include "ILI9327.h" // EL _CD DRIVERSZ
#include "LCD_Draw.h"
#include "LCD_Config.h"
    
// Macros N stuffs
#include "macros.h"
//Delays and timer  
#include "Timer.h" 



// Terminal Libraries 
#include "Terminal.h"


#include "Assw9.h"

void ILI9327_INIT(void);




// kill these 
void testanal(void);                    
void testLibrary(void);
 
 
                         
void main(void) {
   float f = 3.14 ;
         int x, y;
   int colorFill;
	char *helloworld = "he";
	   
   ILI9327_INIT();
   
  terminalemulator();            
  Terminal_Set_Properties(2, 1, 0xFFFFFF);

  printf("printf is werkin!");
	while(1){
	
       printf("printf is werkin!");
	}

}

void ILI9327_INIT(void){
     ILI9327_INITALIZE(); 
    
    return; 
}

 
void testanal(void){

    DDRAD = 0xFF; 
    //ATDDIEN = 0x00;
  
  while(1){
      
      ILI9327_RESET_HIGH();
       ILI9327_CS_HIGH();
        ILI9327_RS_HIGH();
        ILI9327_WR_HIGH();  
         ILI9327_RD_HIGH();
         
    	Timer_Delay_1ms(5);
      
        ILI9327_CS_LOW() ; 
       ILI9327_RS_LOW();  
       ILI9327_WR_LOW();
       ILI9327_RD_LOW();  
      ILI9327_RESET_LOW() ;
      
    	Timer_Delay_1ms(5);
  
  }    
   

}


// CRAPPY TEST ROUTINE !!! YAY IT SUCKS
void testLibrary(void){
   int x, y;
   int colorFill;
	char *helloworld = "he"; 
		//ReadBMP_ARRAY(40,40,BMP_IMAGE2);
//	for (int y= 3; y < 4; y++){
//		pointProperties->Rotation= y; 
		    ILI9327_Fill_Rectangle(0,0,400,240,0x000000); 
		
		LCD_Write_Line("Demo for Rotation: ",50,180,2,0xFFFFFF);
	//	pointCurrent->xPosition = 130;
	//	pointCurrent->yPosition = 40; //// if the string goes off the screen my code doesn't care doesn't display at all only x is cared about
	//	pointCurrent->size = 9;
		LCD_Write_Char(0x30);
		Timer_Delay_1ms(6000);
			
		    ILI9327_Fill_Rectangle(0,0,400,240,0x000000); ;
		for (colorFill=0; colorFill <12; colorFill++){
			LCD_Draw_FillCircle(colorFill*20, 10*colorFill*2, 20+(colorFill*10), 1, colorArray[colorFill]);
		}
		
	    ILI9327_Fill_Rectangle(0,0,400,240,0x000000); 
		
		for ( colorFill=0; colorFill <16; colorFill++){
			LCD_Fill_Rectangle(0,0,500,500, colorArray[colorFill]);
		}
		    ILI9327_Fill_Rectangle(0,0,400,240,0x000000); 

		for (x=0; x < 12; x++)
		{
			for (y=0; y < 16; y++ )
			{
				LCD_Draw_Line(0,0,x*20,y*30,2,colorArray[x]);
			}
		}
	
		    ILI9327_Fill_Rectangle(0,0,400,240,0x000000);  
		Timer_Delay_1ms(6000);
		
		
		LCD_Write_Line("Standard Terminal Font:",10, 220,2,0xFFFFFF);  
		LCD_Write_Line("!#$%&'()*+,-.0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[]^_`abcdefghijklmnopqrstuvwxyz", 20,180,1, 0xFFFFFF);
		LCD_Write_Line("Arial Font:",10, 120,2,0xFFFFFF);  
	//	LCD_Write_Style_Line(FontDemo,20,80,1, 0xFFFFFF);	
		Timer_Delay_1ms(6000);
	
	
	
		
		    ILI9327_Fill_Rectangle(0,0,400,240,0x000000); 
	//	ReadBMP_ARRAY(0,150, 2,BMP_IMAGE);
//		ReadBMP_ARRAY(10,0, 1,BMP_IMAGE);

printf("\n Lets display some variables! \n Hex: 0x%x 0x%x 0x%x 0x%x \n Decimal: %d \n String: %s",
1,2,3,4 , 42, helloworld);
printf(" You are currently viewing the display in rotation: %d ", y);
printf("\n Thanks for choosing my software be sure to check out my other libraries and demos on www.electricsheep.info");

		Timer_Delay_1ms(6000);
		

	
}
