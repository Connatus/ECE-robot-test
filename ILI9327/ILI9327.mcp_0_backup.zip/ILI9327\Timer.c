#include "Timer.h" 

void Timer_Delay_10us(int k) {
// setup vars = 5us delay
    unsigned int total_delay = 0; 
    TSCR1 = 0x90;      /* enable TCNT and fast timer flag clear */
    TSCR2 = TSCR2_TIMER_PR_1;      /* disable TCNT interrupt, set prescaler to 1 */
    TIOS |=  TIOS_IOS0_MASK;       /* enable OC0 function */

    total_delay = 80; // 80 gives delay of 10us 
    total_delay *= k; // multiply by desired delay 
    total_delay -= TC_10US_DELAY_OFFSET; // sub 5us from delay // as setup takes 5us
    
    TC0 = TCNT + total_delay; /* start an OC0 operation */
    
  while(!(TFLG1 & 0x01 )); /* wait for PT0 to go high */
} 
 
void Timer_Delay_100us(int k) {
// setup vars = 5us delay
    unsigned int total_delay = 0; 
    TSCR1 = 0x90;      /* enable TCNT and fast timer flag clear */
    TSCR2 = TSCR2_TIMER_PR_8;      /* disable TCNT interrupt, set prescaler to 1 */
    TIOS |=  TIOS_IOS0_MASK;       /* enable OC0 function */

    total_delay = 100; // 100 gives delay of 100us 
    total_delay *= k; // multiply by desired delay 
    total_delay -= 4; // sub 5us from delay // as setup takes 5us
    
    TC0 = TCNT + total_delay; /* start an OC0 operation */
    
  while(!(TFLG1 & 0x01 )); /* wait for PT0 to go high */
} 



void Timer_Delay_1ms(int k) {
// setup vars = 5us delay
    unsigned int total_delay = 0; 
    TSCR1 = 0x90;      /* enable TCNT and fast timer flag clear */
    TSCR2 = TSCR2_TIMER_PR_64;      /* disable TCNT interrupt, set prescaler to 1 */
    TIOS |=  TIOS_IOS0_MASK;       /* enable OC0 function */

    total_delay = 125; // 125 gives delay of 1ms 
    total_delay *= k; // multiply by desired delay 
    total_delay -= 1; // sub 5us from delay // as setup takes 5us
    
    TC0 = TCNT + total_delay; /* start an OC0 operation */
    
  while(!(TFLG1 & 0x01 )); /* wait for PT0 to go high */
} 


void Timer_Delay_10ms(int k) {
// setup vars = 5us delay
    unsigned int total_delay = 0; 
    TSCR1 = 0x90;      /* enable TCNT and fast timer flag clear */
    TSCR2 = TSCR2_TIMER_PR_128;      /* disable TCNT interrupt, set prescaler to 1 */
    TIOS |=  TIOS_IOS0_MASK;       /* enable OC0 function */

    total_delay = 620; // 620 gives delay of 10ms 
    total_delay *= k; // multiply by desired delay 
    total_delay -= 1; // sub 5us from delay // as setup takes 5us
    
    TC0 = TCNT + total_delay; /* start an OC0 operation */
    
  while(!(TFLG1 & 0x01 )); /* wait for PT0 to go high */
} 


//delay 10us 
// delay 100us
/// delay 1ms 
/// delay 10ms 
/// delay 100ms 
